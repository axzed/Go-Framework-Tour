package main

import (
	"gitee.com/geektime-geekbang/geektime-go/userapp/backend/thirdparty"
	"gitee.com/geektime-geekbang/geektime-go/userapp/backend/web/handler"
	"gitee.com/geektime-geekbang/geektime-go/web"
	_ "net/http/pprof"
)

func main() {

	userHdl := &handler.UserHandler{}
	// err := os.MkdirAll("./" + api.StaticDir, os.ModePerm)
	// if err != nil {
	// 	panic(err)
	// }

	thirdparty.InitZipkin("user-web")
	server := web.NewHTTPServer()
	// server.Use()
	//s := server.NewServer(":8080")
	server.Post("/login", userHdl.Login)
	server.Post("/signup", userHdl.SignUp)
	server.Get("/profile", userHdl.Profile)
	server.Post("/update", userHdl.Update)
	server.Post("/upload", userHdl.Upload)
	server.Get("/static/", userHdl.Static)

	if err := server.Start(":8081"); err != nil {
		panic(err)
	}
}

// func CorsFilterChain(next server.Filter) server.Filter {
// 	return func(ctx *server.Context) {
// 		ctx.W.Header().Set("Access-Control-Allow-Origin", "http://localhost:8082")
// 		ctx.W.Header().Set("Access-Control-Allow-Credentials", "true")
// 		ctx.W.Header().Set("content-type", "application/json")
//
// 		if ctx.W.Header().Get("Access-Control-Allow-Headers") == ""{
// 			ctx.W.Header().Add("Access-Control-Allow-Headers", "Content-Type")
// 		}
// 		if ctx.R.Method == "OPTIONS" {
// 			ctx.W.WriteHeader(200)
// 		} else {
// 			next(ctx)
// 		}
// 	}
// }

// func TracingFilterChain(next server.Filter) server.Filter  {
// 	return func(ctx *server.Context) {
// 		if ctx.R.Method != "OPTIONS" {
// 			name := ctx.R.Method + "#" + ctx.R.URL.Path
// 			span := opentracing.StartSpan(name)
// 			ctx.Ctx = opentracing.ContextWithSpan(ctx.Ctx, span)
// 			defer span.Finish()
// 		}
// 		next(ctx)
// 	}
// }


