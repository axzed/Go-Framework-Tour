package handler

import (
	"bytes"
	"errors"
	"fmt"
	"gitee.com/geektime-geekbang/geektime-go/userapp/backend/logs"
	"gitee.com/geektime-geekbang/geektime-go/userapp/dto"
	"gitee.com/geektime-geekbang/geektime-go/web"
	"github.com/google/uuid"
	"io"
	"net/http"
	"os"
	"regexp"
	"strings"
)

const imgSever = "http://localhost:8080"
const StaticDir = "static"

type UserHandler struct {

}

func (h *UserHandler) Login(ctx *web.Context) {
	// reuse this definition
	req := &dto.LoginReq{}
	err := ctx.BindJSON(req)
	if err != nil {
		logs.Errorf("request error: %v", err)
		ctx.SystemError("request error")
		return
	}
	resp, err := client.UserClient.Login(ctx.Ctx, req)
	if err != nil {
		logs.Errorf("login error: %v", err)
		ctx.SystemError("system error")
		return
	}

	if resp.Code == dto.LoginRespErrCode_LOGIN_OK {
		ctx.SetToken(resp.Token)
		ctx.Ok(resp.User)
		return
	}

	if resp.Code == dto.LoginRespErrCode_USER_OR_PASSWORD_NOT_RIGHT {
		ctx.SystemError("email or password not correct")
		return
	} else {
		logs.Errorf("unexpected error code : %v ", resp.Code)
		ctx.SystemError("system error")
		return
	}
}

func (h *UserHandler) Static(ctx *web.Context) {
	path := ctx.R.URL.Path
	fileName := path[strings.LastIndex(path, "/" +StaticDir+ "/") + 7:]
	file, err := os.Open(StaticDir + fileName)
	if err != nil {
		logs.Errorf("could not open the file")
		ctx.SystemError("system error")
		return
	}
	fi, _ := file.Stat()
	ctx.W.Header().Set("Content-Type", "image/png")
	ctx.W.Header().Set("Content-Length", fmt.Sprintf("%d", fi.Size()))

	content, err := io.ReadAll(file)
	if err != nil {
		logs.Errorf("could not read the file")
		ctx.SystemError("system error")
		return
	}
	http.ServeContent(ctx.W, ctx.R, fileName, fi.ModTime(), bytes.NewReader(content))
}

func (h *UserHandler) Upload(ctx *web.Context) {
	err := ctx.R.ParseMultipartForm(32 << 20)
	if err != nil {
		logs.Errorf("parse uploading file failed: %v", err)
		ctx.SystemError("system error")
	}
	file, handler, err := ctx.R.FormFile("file")
	if err != nil {
		fmt.Println(err)
		return
	}
	defer file.Close()
	fileName := uuid.New().String()
	suffix := handler.Filename[strings.LastIndex(handler.Filename, "."):]
	path := "/" + StaticDir + "/"+fileName + suffix
	f, err := os.OpenFile("."+ path , os.O_WRONLY|os.O_CREATE, 0666)
	if err != nil {
		fmt.Println(err)
		return
	}
	defer f.Close()
	io.Copy(f, file)
	ctx.Ok(imgSever + path)
}

func (h *UserHandler) Update(ctx *web.Context) {
	u := &dto.User{}
	err := ctx.JsonMarshal(u)
	if err != nil{
		ctx.SystemError("invalid input")
		logs.Errorf("invalid input: %v", err)
		return
	}

	resp, err := client.UserClient.UpdateById(ctx.Ctx, &dto.UpdateByIdReq{
		User: u,
	})
	if err != nil {
		ctx.SystemError("update failed")
		logs.Errorf("update failed: %v", err)
		return
	}

	if resp.Affected == 0 {
		ctx.SystemError("system error")
		logs.Errorf("user not found")
		return
	}

	ctx.Ok("ok")

}

func (h *UserHandler) Profile(ctx *web.Context) {

	resp, err := client.UserClient.FindById(ctx.Ctx, &dto.FindByUserIdReq{
		Id: ctx.S.UserId,
	})
	if err != nil {
		logs.Errorf("find user failed: %v", err)
		ctx.SystemError("system error")
		return
	}
	ctx.Ok(resp.User)
}

func (h *UserHandler) SignUp(ctx *web.Context) {
	u := &signUpReq{}
	err := ctx.JsonMarshal(u)
	if err != nil {
		ctx.SystemError(err.Error())
		return
	}

	err = checkSignUpReq(u)
	if err != nil {
		ctx.SystemError(err.Error())
	}

	_, err = client.UserClient.CreateUser(ctx.Ctx, &dto.CreateUserReq{
		User: &dto.User{
			Email: u.Email,
			Password: u.Password,
		},
	})
	if err != nil {
		ctx.SystemError(err.Error())
		return
	}
	ctx.Ok("created")
}

const emailPattern = "(.+)@(.+){2,}\\.(.+){2,}"

func checkSignUpReq(req *signUpReq) error {
	if len(req.Email) == 0 || len(req.Password) ==0 || len(req.ConfirmPwd) ==0 {
		return errors.New("you must input all fields")
	}

	if req.Password != req.ConfirmPwd {
		return errors.New("you must confirm your password")
	}

	if len(req.Password) != 32 {
		return errors.New("invalid password")
	}

	ok, err := regexp.Match(emailPattern, []byte(req.Email))
	if !ok || err !=nil {
		return errors.New("invalid email address")
	}
	return nil
}

type signUpReq struct {
	Email string
	Password string
	ConfirmPwd string
}

