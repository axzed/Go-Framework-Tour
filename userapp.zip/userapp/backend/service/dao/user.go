package dao

import (
	"context"
	"database/sql"
	"gitee.com/geektime-geekbang/geektime-go/user-service/dao/model"
	"time"
)

const operationNamePrefix = "dao."

func GetUserByEmail(ctx context.Context, email string) (*model.User, error) {
	name := operationNamePrefix + "GetUserByEmail"
	span, _ := opentracing.StartSpanFromContext(ctx, name)
	defer span.Finish()
	row := getUserByEmailStmt.QueryRow(email)
	u := &model.User{}
	err := row.Scan(&u.Id, &u.Name, &u.Avatar, &u.Email, &u.Password, &u.CreateTime, &u.UpdateTime)
	return u, err
}

func GetUserById(ctx context.Context, id uint64) (*model.User, error) {
	name := operationNamePrefix + "GetUserById"
	span, _ := opentracing.StartSpanFromContext(ctx, name)
	defer span.Finish()
	row := getUserByIdStmt.QueryRow(id)
	u := &model.User{}
	err := row.Scan(&u.Id, &u.Name, &u.Avatar, &u.Email, &u.Password, &u.CreateTime, &u.UpdateTime)
	return u, err
}

func InsertUser(ctx context.Context, u *model.User) error {
	name := operationNamePrefix + "InsertUser"
	span, _ := opentracing.StartSpanFromContext(ctx, name)
	defer span.Finish()
	ret, err := insertStmt.ExecContext(ctx, u.Name, u.Avatar, u.Email, u.Password, u.CreateTime, u.UpdateTime)
	if err != nil {
		return err
	}
	id, err := ret.LastInsertId()
	u.Id = uint64(id)
	return err
}

func UpdateUser(ctx context.Context, u *model.User) (int64, error) {
	name := operationNamePrefix + "UpdateUser"
	span, _ := opentracing.StartSpanFromContext(ctx, name)
	defer span.Finish()
	now := time.Now().Unix()
	res, err := updateStmt.ExecContext(ctx, u.Name, u.Email, u.Avatar, now, u.Id)
	if err != nil {
		return 0, err
	}
	return res.RowsAffected()
}

var getUserByEmailStmt *sql.Stmt
var getUserByIdStmt *sql.Stmt
var insertStmt *sql.Stmt
var updateStmt *sql.Stmt

func initPrepareStatement() error {
	var err error
	getUserByEmailStmt, err = db.Prepare("SELECT * FROM `user` where email = ?")
	getUserByIdStmt, err = db.Prepare("SELECT * FROM `user` where id = ?")
	if err != nil {
		return err
	}
	insertStmt, err = db.Prepare(`
INSERT INTO user(name, avatar, email, password, create_time, update_time) VALUE (?, ?, ?, ?, ?, ?)
`)
	updateStmt, err = db.Prepare("update user set name = ?, email = ?, avatar = ?, update_time= ? where id = ?")
	return err
}
