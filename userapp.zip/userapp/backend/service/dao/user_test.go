package dao

import (
	"context"
	"gitee.com/geektime-geekbang/geektime-go/user-service/dao/model"
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestUser(t *testing.T) {
	u := &model.User{
		Name: "my name",
		Avatar: "my avatar",
		Email: "my email",
		Password: "my password",
	}
	err := InsertUser(context.Background(), u)
	assert.Nil(t, err)
	assert.True(t, u.Id > 0)

	u.Email = "my email plus"

	_, err = UpdateUser(context.Background(), u)
	assert.Nil(t, err)

	u, err = GetUserByEmail(context.Background(), "my email plus")
	assert.Nil(t, err)
	assert.NotNil(t, u)
}
