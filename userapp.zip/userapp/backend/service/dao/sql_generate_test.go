package dao

import (
	"fmt"
	"github.com/stretchr/testify/assert"
	"os"
	"strings"
	"testing"
)

func TestGenerateData(t *testing.T) {
	sqlTemplate := `
INSERT INTO entry_task.user (name, avatar, email, password, create_time, update_time) 
VALUES %s 
;`
	sqlFile, err := os.OpenFile("users.sql", os.O_APPEND|os.O_CREATE|os.O_WRONLY | os.O_TRUNC, 0644)
	assert.Nil(t, err)
	defer sqlFile.Close()
	for i := 0; i < 1000; i++ {
		_, err = sqlFile.WriteString(fmt.Sprintf(sqlTemplate, generateValues(i)))
		assert.Nil(t, err)
	}
}
const itr = 10000
func generateValues(loop int) string {
	index := loop * itr
	start := generateValue(index)
	sb := &strings.Builder{}
	sb.WriteString(start)
	for i := 1; i < itr; i++ {
		index = index + 1
		sb.WriteString(",\n")
		sb.WriteString(generateValue(index))
	}
	return sb.String()
}

func generateValue(index int) string {
	// 5416d7cd6ef195a0f7622a9c56b55e84
	// 5416d7cd6ef195a0f7622a9c56b55e84 1q2w3e4r
	return fmt.Sprintf(`('1234', 'http://localhost:8080/static/bb53dc70-8e91-4af6-a5a9-5a5c34888a99.png', '123%d@qq.com', '35343136643763643665663139356130663736323261396335366235356538343630444433353334D41D8CD98F00B204E9800998ECF8427E', 1625109812, 1625110441)`, index)
}
