package main

import (
	"gitee.com/geektime-geekbang/geektime-go/rpc"
	"gitee.com/geektime-geekbang/geektime-go/thirdparty"
	"gitee.com/geektime-geekbang/geektime-go/user-service/cache"
	"gitee.com/geektime-geekbang/geektime-go/user-service/service"
	"gitee.com/geektime-geekbang/geektime-go/user-service/token"
	"github.com/golang/protobuf/proto"
	"log"
	"net/http"
	_ "net/http/pprof"
	"time"
)

func main() {
	rc := redis.NewClient(&redis.Options{
		Addr: "localhost:6379",
		Password: "abc",
	})

	thirdparty.InitZipkin("user-server")

	c, err := cache.NewRedisCache( rc, cache.WithMarshalFunc(func(m interface{}) ([]byte, error) {
			return proto.Marshal(m.(proto.Message))
		}), cache.WithUnmarshalFunc(func(b []byte, m interface{}) error {
			return proto.Unmarshal(b, m.(proto.Message))
		}))

	if err != nil {
		log.Fatal(err)
	}

	tm := token.NewManager(rc, time.Minute * 15)

	tracingBuilder := &rpc.ServerSideTracingFilterBuilder{
	}

	svr := rpc.NewToyProtocolServer("127.0.0.1:8081",
		rpc.ExtractContextFilterBuilder, tracingBuilder.Build)
	svr.RegisterService(service.NewUserService(c, tm))
	go func() {
		http.ListenAndServe(":6060", nil)
	}()
	if err := svr.Start(); err != nil {
		log.Fatal(err)
	}
}

