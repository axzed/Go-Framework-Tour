package token

import (
	"errors"
	"time"
)

const tokenKeyPattern = "/token/%d"
const key = "1q2w#E$R"

type Manager struct {
	client *redis.Client
	expire time.Duration
}

func NewManager(client *redis.Client, expire time.Duration) *Manager {
	return &Manager{
		client: client,
		expire: expire,
	}
}

type AccessTokenTicket struct {
	AccessToken string `json:"accessToken"`
}

func (c *Manager) CreateAccessToken(uid uint64, startTime int64) (string, error) {
	// using the uid as the jwtId
	tokenString, err := c.EncodeAccessToken(uid, uid, startTime)
	if err != nil {
		return "", err
	}

	//err = c.client.Set(context.Background(), fmt.Sprintf(tokenKeyPattern, uid), tokenString, c.expire).Err()
	//if err != nil {
	//	return "", fmt.Errorf("set token error %v", err)
	//}
	return tokenString, nil
}

func (c *Manager) CheckAccessToken(tokenStr string) (uint64, error) {
	sc, err := c.DecodeAccessToken(tokenStr)
	if err != nil {
		return 0, err
	}
	uid := sc["jti"].(float64)
	uidInt := uint64(uid)
	//err = c.client.Get(context.Background(), fmt.Sprintf(tokenKeyPattern, uidInt)).Err()
	//if err != nil {
	//	return 0, err
	//}
	return uidInt, nil
}

func (c *Manager) RefreshAccessToken(tokenStr string, startTime int64) (string, error) {
	sc, err := c.DecodeAccessToken(tokenStr)
	if err != nil {
		return "", err
	}
	uid := sc["jti"].(float64)
	uidInt := uint64(uid)
	return c.CreateAccessToken(uidInt, startTime)
}

func (c *Manager) EncodeAccessToken(jwtId uint64, uid uint64, startTime int64) (tokenStr string, err error) {
	jwtToken := jwt.New(jwt.SigningMethodHS256)
	claims := make(jwt.MapClaims)
	claims["jti"] = jwtId
	//claims["iss"] = c.config.AccessTokenIss
	claims["sub"] = uid
	claims["iat"] = startTime
	claims["exp"] = startTime + int64(c.expire / time.Second)
	jwtToken.Claims = claims
	tokenStr, err = jwtToken.SignedString([]byte(key))
	if err != nil {
		return
	}
	return
}

func (c *Manager) DecodeAccessToken(tokenStr string) (resp map[string]interface{}, err error) {
	tokenParse, err := jwt.Parse(tokenStr, func(jwtToken *jwt.Token) (interface{}, error) {
		return []byte(key), nil
	})
	if err != nil {
		return
	}
	var flag bool
	resp, flag = tokenParse.Claims.(jwt.MapClaims)
	if !flag {
		err = errors.New("assert error")
		return
	}
	return
}

