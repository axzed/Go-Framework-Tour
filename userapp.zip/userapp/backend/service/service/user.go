package service

import (
	"context"
	"crypto/md5"
	"crypto/sha1"
	"database/sql"
	"errors"
	"fmt"
	"gitee.com/geektime-geekbang/geektime-go/proto/gen/dto"
	logs "gitee.com/geektime-geekbang/geektime-go/user-log"
	"gitee.com/geektime-geekbang/geektime-go/user-service/cache"
	"gitee.com/geektime-geekbang/geektime-go/user-service/dao"
	"gitee.com/geektime-geekbang/geektime-go/user-service/dao/model"
	"gitee.com/geektime-geekbang/geektime-go/user-service/token"
	"golang.org/x/crypto/pbkdf2"
	"strings"
	"time"
)

const cacheByIdFormat = "user-%d"
const cacheByEmailFormat = "user-email-%s"

type UserService struct {
	cache        cache.Cache
	tokenManager *token.Manager
}

func NewUserService(cache cache.Cache, manager *token.Manager) *UserService {
	return &UserService{
		cache: cache,
		tokenManager: manager,
	}
}

func (u *UserService) FindById(ctx context.Context, req *dto.FindByUserIdReq) (*dto.FindByUserIdResp, error) {

	if req.Id == 0 {
		return nil, errors.New("you must pass user id")
	}

	key := fmt.Sprintf(cacheByIdFormat, req.Id)
	//
	if user := u.findFromCache(ctx, key); user != nil {
		return &dto.FindByUserIdResp{
			User: user,
		}, nil
	}

	usr, err := dao.GetUserById(ctx, req.Id)
	if err != nil {
		return nil, err
	}

	pb := usr.ToPB()
	u.cacheUser(ctx, key, pb)

	return &dto.FindByUserIdResp{
		User: pb,
	}, nil
}

func (u *UserService) CheckToken(ctx context.Context, req *dto.CheckTokenReq) (*dto.CheckTokenReply, error) {
	uid, err := u.tokenManager.CheckAccessToken(req.Token)
	if err != nil {
		return nil, err
	}

	return &dto.CheckTokenReply{
		UserId: uid,
	}, nil
}

func (u *UserService) findFromCache(ctx context.Context, key string) *dto.User {
	if u.cache == nil {
		return nil
	}
	user:= &dto.User{}
	err:= u.cache.Get(ctx, key, user)
	if err != nil {
		logs.Errorf("user missing cache: %s, err: %v", key, err)
		return nil
	}
	return user
}

func (u *UserService) UpdateById(ctx context.Context, req *dto.UpdateByIdReq) (*dto.UpdateByIdResp, error) {
	if req.User == nil || req.User.Id == 0 {
		return nil, errors.New("you must pass user id")
	}

	row, err := dao.UpdateUser(ctx, &model.User{
		Id: req.User.Id,
		Name: req.User.Name,
		Email: req.User.Email,
		Avatar: req.User.Avatar,
	})

	if err != nil {
		if strings.HasPrefix(err.Error(), "Error 1062: Duplicate entry") {
			return nil, errors.New("duplicate email")
		}
	}

	err = u.cache.Delete(ctx, fmt.Sprintf(cacheByIdFormat, req.User.Id))
	if err != nil {
		logs.Errorf("could not remove cache")
	}

	return &dto.UpdateByIdResp{
		Affected: row,
	}, err
}

func (u *UserService) Login(ctx context.Context, req *dto.LoginReq) (*dto.LoginResp, error){
	key := fmt.Sprintf(cacheByEmailFormat, req.Email)
	//pb := u.findFromCache(ctx, key)
	var pb *dto.User
	if pb == nil {
		usr, err := dao.GetUserByEmail(ctx, req.Email)
		if err != nil {
			if err == sql.ErrNoRows {
				return &dto.LoginResp{
					Code: dto.LoginRespErrCode_USER_OR_PASSWORD_NOT_RIGHT,
				}, nil
			}
			return nil, err
		}
		pb = usr.ToPBWithSensitive()
		u.cacheUser(ctx, key, pb)
	}
	encode := encryptPwdByMd5(req.Password, generateSalt(pb.CreateTime))
	if encode != pb.Password {
		return &dto.LoginResp{
			Code: dto.LoginRespErrCode_USER_OR_PASSWORD_NOT_RIGHT,
		}, nil
	}

	tk, err := u.tokenManager.CreateAccessToken(pb.Id, time.Now().Unix())
	if err != nil {
		return nil, err
	}

	pb.Password = ""
	return &dto.LoginResp{
		User: pb,
		Token: tk,
	}, nil
}

func (u *UserService) match(ct uint64, reqPwd string, pwd string) bool {
	encode := encryptPwdByMd5(reqPwd, generateSalt(ct))
	return pwd == encode
}

func (u *UserService) cacheUser(ctx context.Context, key string, value *dto.User) {
	if u.cache != nil {
		if err := u.cache.Put(ctx, key, value, time.Hour); err != nil {
			logs.Errorf("cache user error: %v", err)
		}
	}
}

func (u *UserService) invalidCache(ctx context.Context, key string) {
	if u.cache != nil {
		if err := u.cache.Delete(ctx, key); err != nil {
			logs.Errorf("could not remove data from cache: %v", err)
		}
	}
}

func(u *UserService) CreateUser(ctx context.Context, req *dto.CreateUserReq) (*dto.CreateUserResp, error) {
	if req.User == nil {
		return nil, errors.New("user data not exist")
	}
	now := uint64(time.Now().Unix())
	salt := generateSalt(now)

	um := &model.User{
		Name:       req.User.Name,
		Avatar:     req.User.Avatar,
		Email:      req.User.Email,
		Password:   encryptPwdByMd5(req.User.Password, salt),
		CreateTime: now,
		UpdateTime: now,
	}
	logs.Info(um.Password)
	err := dao.InsertUser(ctx, um)
	if err != nil {
		if strings.HasPrefix(err.Error(), "Error 1062: Duplicate entry") {
			return nil, errors.New("duplicate email")
		}
		return nil, err
	}

	pb := um.ToPB()
	u.cacheUser(ctx, fmt.Sprintf(cacheByIdFormat, um.Id), pb)

	return &dto.CreateUserResp{
		UserId: um.Id,
	}, nil
}

func generateSalt(seed uint64) string {
	return fmt.Sprintf("%X", seed)
	//p, err := rand.Prime(rand.Reader, 64)
	//if err != nil {
	//	logs.Errorf("could not generate salt")
	//	return "", errors.New("system error")
	//}
	//return fmt.Sprintf("%X", p.Bytes()), nil
}

func encryptPwdByPbkdf2(raw string, salt string) string {
	return fmt.Sprintf("%X", pbkdf2.Key([]byte(raw), []byte(salt), 4096, 32, sha1.New))
}

func encryptPwdByMd5(raw string, salt string) string {
	return fmt.Sprintf("%X", md5.New().Sum([]byte(raw + salt)))
}

func (u *UserService) GetUserByEmail(ctx context.Context, req *dto.GetUserByEmailReq) (*dto.GetUserByEmailReply, error) {
	if len(req.Email) == 0 {
		return nil, errors.New("invalid email")
	}

	um, err := dao.GetUserByEmail(ctx, req.Email)
	if err != nil {
		return nil, err
	}

	return &dto.GetUserByEmailReply{
		User: um.ToPB(),
	}, nil

}

func (u *UserService) ServiceName() string {
	return "user"
}

