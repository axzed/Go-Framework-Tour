package cache

import (
	"context"
	"time"
)


type RedisCache struct {
	client *redis.Client
	marshal func (m interface{}) ([]byte, error)
	unmarshal func(b []byte, m interface{}) error
}


type RedisCacheOpt func(cache *RedisCache)

func WithMarshalFunc(f func (m interface{}) ([]byte, error)) RedisCacheOpt {
	return func(cache *RedisCache) {
		cache.marshal = f
	}
}

func WithUnmarshalFunc(f  func(b []byte, m interface{}) error) RedisCacheOpt {
	return func(cache *RedisCache) {
		cache.unmarshal = f
	}
}

func NewRedisCache(client *redis.Client, opts ...RedisCacheOpt) (Cache, error) {
	r := &RedisCache{
		client: client,
	}

	for _, opt := range opts {
		opt(r)
	}
	return r, nil
}

func (r *RedisCache) Put(ctx context.Context, key string,
	value interface{}, expire time.Duration) error {
	if r.marshal != nil {
		data, err := r.marshal(value)
		if err != nil {
			return err
		}
		cmd := r.client.Set(ctx, key, data, expire)
		return cmd.Err()
	}
	cmd := r.client.Set(ctx, key, value, expire)
	return cmd.Err()
}

func (r *RedisCache) Get(ctx context.Context, key string, value interface{}) error {
	cmd := r.client.Get(ctx, key)
	if r.unmarshal != nil {
		data, err :=cmd.Bytes()
		if err != nil {
			return err
		}
		return r.unmarshal(data, value)
	}
	return cmd.Scan(value)
}

func (r *RedisCache) Delete(ctx context.Context, key string) error {
	cmd := r.client.Del(ctx, key)
	return cmd.Err()
}


