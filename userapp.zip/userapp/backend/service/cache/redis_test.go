package cache

import (
	"context"
	"gitee.com/geektime-geekbang/geektime-go/proto/gen/dto"
	"github.com/golang/protobuf/proto"
	"github.com/stretchr/testify/assert"
	"testing"
	"time"
)

func TestNewRedisCache(t *testing.T) {
	rc := redis.NewClient(&redis.Options{
		Addr: "localhost:6379",
		Password: "abc",
	})
	cache, _ := NewRedisCache(rc, WithMarshalFunc(func(m interface{}) ([]byte, error) {
			return proto.Marshal(m.(proto.Message))
		}), WithUnmarshalFunc(func(b []byte, m interface{}) error {
			return proto.Unmarshal(b, m.(proto.Message))
		}))
	user := &dto.User{
		Name: "hello",
		Password: "1234",
	}

	key := "my-user"
	err := cache.Put(context.Background(), key, user, time.Minute)
	assert.Nil(t, err)

	cu := &dto.User{}
	err = cache.Get(context.Background(), key, cu)
	assert.Nil(t, err)
	assert.Equal(t, "hello", cu.Name)
	assert.Equal(t, "1234", cu.Password)
}