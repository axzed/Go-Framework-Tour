package logs

import (
	"fmt"
	"log"
	"os"
)

func init() {
	err := os.MkdirAll("logs", os.ModePerm)
	if err != nil {
		log.Fatalf("could not create logs dir: %v", err)
	}
	logFile, err := os.OpenFile("logs/app.log", os.O_APPEND|os.O_CREATE|os.O_RDWR, 0644)
	if err != nil {
		log.Fatalf("could not init log: %v", err)
	}
	log.SetOutput(logFile)
}

func Errorf(f string, args...interface{}) {
	msg := fmt.Sprintf(f, args...)
	log.Printf("ERROR: %s \n", msg)
}

func Info(msg string) {
	log.Printf("INFO: %s\n", msg)
}
