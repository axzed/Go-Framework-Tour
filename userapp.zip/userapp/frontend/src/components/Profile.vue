<template>
  <div class="container">
    <div class="col-3"></div>
    <div class="col-6">

    </div>
    <b-alert :show="errMsg.length > 0" variant="danger">{{errMsg}}</b-alert>
    <b-card :title="user.name || 'Your Name'" :img-src="user.avatar" img-alt="Card image" img-left class="mb-3">
      <b-list-group flush>
        <b-list-group-item>Email: {{user.email || 'yo ur email'}}</b-list-group-item>
        <b-list-group-item><b-button v-on:click="goToEdit" variant="primary">编辑</b-button></b-list-group-item>
      </b-list-group>
    </b-card>

  </div>
</template>

<script>
import {BCard, BListGroup, BListGroupItem, BButton} from 'bootstrap-vue'
export default {
  name: "Profile",
  comments: {
    BCard,
    BListGroup,
    BListGroupItem,
    BButton
  },
  created() {
    this.$http.get(process.env.VUE_APP_ENDPOINT + "/profile", {}, {
      withCredential:true
    })
    .then(resp => {
      if (resp.body !== undefined && resp.body.Data !== undefined) {
        this.user = resp.body.Data
      } else {
        this.errMsg = 'unknown error'
      }
    }, resp => {
      console.log("profile failed")
      if (resp.body !== undefined && resp.body.Msg !== undefined) {
        this.errMsg = resp.body.Msg
      } else {
        this.errMsg ='system error'
      }
    })
  },
  data() {
    return {
      errMsg: '',
      user: {
        email: "",
        avatar: "",
      }
    }
  },
  methods: {
    reset() {

    },
    goToEdit() {
      this.$router.push("/edit")
    }
  }
}
</script>

<style scoped>

</style>