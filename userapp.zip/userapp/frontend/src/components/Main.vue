<template>
  <div>
    <h1>Welcome to simple-user demo</h1>
    <div class="col-6 container">
      <b-form>
        <b-form-group id="input-group-1">
          <b-form-input
              id="input-1"
              v-model="form.email"
              type="email"
              placeholder="Enter email"
              required
              :invalid-feedback="'invalid email'"
              :state="isValidEmail"
          ></b-form-input>
        </b-form-group>
        <br/>

        <b-form-group id="input-group-2">
          <b-form-input
              id="input-2"
              v-model="form.password"
              type="password"
              placeholder="8~16 characters"
              required
              :invalid-feedback="invalidPwd"
              :state="isValidPwd"
          ></b-form-input>
        </b-form-group>

        <br/>
        <b-form-group  v-if="signup" id="input-group-2">
          <b-form-input
              id="input-2"
              v-model="form.confirmPwd"
              placeholder="confirm password"
              type="password"
              required
              :invalid-feedback="notMatchPwd"
              :state="form.confirmPwd.length >= 8 && form.password === form.confirmPwd"
          ></b-form-input>
          <br />
        </b-form-group>

        <b-alert :show="msg.length > 0" variant="success">{{msg}}</b-alert>
        <b-alert :show="errMsg.length > 0" variant="danger">{{errMsg}}</b-alert>

        <b-button v-if="!signup" v-on:click="login" variant="primary">Sign In</b-button>
        &nbsp;&nbsp;
        <a v-if="!signup" v-on:click="toSignUp" href="#">Create Account</a>
        <b-button v-if="signup" v-on:click="signUp" variant="danger">Sign Up</b-button>

<!--        <b-button v-on:click="goToProfile(123)" variant="danger">GO GO GO</b-button>-->
        &nbsp;&nbsp;
        <a v-if="signup" v-on:click="toLogin" href="#">Already have account</a>
        <br />
        <br />
      </b-form>
    </div>
  </div>
</template>

<script>

import { BForm, BButton, BFormGroup, BFormInput, BAlert } from 'bootstrap-vue'
import md5 from 'blueimp-md5'

export default {
  name: "Main",
  comments:{
    BForm,
    BButton,
    BFormGroup,
    BFormInput,
    BAlert
  },
  data() {
    return {
      msg: '',
      errMsg:'',
      form: {
        email: '',
        password: '',
        confirmPwd: '',
      },
      signup: false,
    }
  },
  methods: {
    toSignUp() {
      this.signup = true
      this.resetAlert()
    },

    toLogin() {
      this.signup = false
      this.resetAlert()
    },
    login() {
      this.resetAlert()
      // let v = this
      let data = {
        "email": this.form.email,
        "password": md5(this.form.password),
      }
      this.$http.post(process.env.VUE_APP_ENDPOINT + "/login", data)
      .then(resp => {
        if (resp.body !== undefined && resp.body.Data !== undefined) {
          this.$router.push("/user/" + resp.body.Data.Id)
        } else {
          this.errMsg = "unknown error"
        }
      }, resp => {
        if (resp.body !== undefined && resp.body.Msg !== undefined) {
          this.errMsg = resp.body.Msg
        } else {
          this.errMsg = "unknown error"
        }
      })

    },
    // signup
    signUp() {
      this.resetAlert()
      // let v = this
      let data = {
        "email": this.form.email,
        "password": md5(this.form.password),
        "confirmPwd": md5(this.form.confirmPwd),
      }
      this.$http.post(process.env.VUE_APP_ENDPOINT + "/signup", data)
      .then(resp => {
        // v.msg = resp.body.Msg
        if (resp.body !== undefined && resp.body.Data !== undefined) {
          this.toLogin()
          this.msg = "create successfully, please login"
        } else {
          this.errMsg = "unknown error"
        }
      }, resp => {
        if (resp.body !== undefined && resp.body.Msg !== undefined) {
          this.errMsg = resp.body.Msg
        } else {
          this.errMsg = "unknown error"
        }
      })
    },

    resetAlert() {
      this.msg = ''
      this.errMsg = ''
    }
  },
  computed: {
    notMatchPwd() {
      return "The password not match"
    },
    invalidPwd() {
      return "the password should have more than 8 characters"
    },

    isValidPwd() {
      if (!this.signup) {
        return undefined
      }
      return this.form.password.length >= 8
    },

    isValidEmail : function() {
      if (!this.signup) {
        return undefined
      }
      let re = /(.+)@(.+){2,}\.(.+){2,}/;
      return re.test(this.form.email.toLowerCase());
    }
  }
}
</script>

<style scoped>

</style>